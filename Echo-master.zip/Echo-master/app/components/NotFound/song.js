import React from 'react';

const NotFound = () =>
  <div>
    <p>We are sorry, this song is removed</p>
  </div>;

export default NotFound;
