export const MEDIA_ENDPOINT = '/api/media';
export const USER_ENDPOINT = '/api/user';
export const PLAYLIST_ENDPOINT = '/api/playlist';
export const ROOT_URL = 'http://localhost:3000';
