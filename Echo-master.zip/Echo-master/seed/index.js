import Genres from './genres';

export {
  Genres,
};
